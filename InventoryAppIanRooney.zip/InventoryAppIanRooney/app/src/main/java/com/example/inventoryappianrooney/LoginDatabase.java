package com.example.inventoryappianrooney;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class LoginDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "logins.db";
    private static final int VERSION = 1;

    public LoginDatabase(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }

    // Defines table and column names
    private static final class LoginTable{
        private static final String TABLE = "logins";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
        private static final String COL_FIRST_NAME = "firstName";
        private static final String COL_LAST_NAME = "lastName";
        private static final String COL_EMAIL = "email";
        private static final String COL_ROLE = "role";
    }

    // Creates table with auto incremented integer key values
    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("create table " + LoginTable.TABLE + " (" +
                LoginTable.COL_ID + " integer primary key autoincrement, " +
                LoginTable.COL_USERNAME + " text, " +
                LoginTable.COL_PASSWORD + " text, " +
                LoginTable.COL_FIRST_NAME + " text, " +
                LoginTable.COL_LAST_NAME + " text, " +
                LoginTable.COL_EMAIL + " text, " +
                LoginTable.COL_ROLE + " text)");
    }

    // Update database version
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("drop table if exists " + LoginTable.TABLE);
        onCreate(db);
    }

    // Revert to previous database version
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion){
        onUpgrade(db, oldVersion, newVersion);
    }

    // Validate username and password
    public boolean validateLogin(String un, String p){

        SQLiteDatabase db = getReadableDatabase();

        // Check whether username is valid
        String sql = "select * from " + LoginDatabase.LoginTable.TABLE + " where username = ? ";
        Cursor cursor = db.rawQuery(sql, new String[] { un });
        if (cursor.moveToFirst()){
            String password = cursor.getString(2); // Get password

            // Check whether passwords match
            if (password.equals(p)){
                return true; // Username and password are correct
            }
        }
        cursor.close();
        return false; // Username or password is incorrect
    }

    // Check whether the username already exists
    public boolean usernameAvailable(String un){

        SQLiteDatabase db = getReadableDatabase();

        // Check whether username is valid
        String sql = "select * from " + LoginDatabase.LoginTable.TABLE + " where username = ? ";
        Cursor cursor = db.rawQuery(sql, new String[] { un });
        if (cursor.moveToFirst()){
            return true;
        }
        cursor.close();
        return false; // Username or password is incorrect
    }

    // Register a new user
    public long addUser(String un, String p, String first, String last, String email, String role){
        SQLiteDatabase db = getWritableDatabase();

        // Check whether the username is available
        if (usernameAvailable(un)){
            return -1;
        }

        ContentValues values = new ContentValues();
        values.put(LoginDatabase.LoginTable.COL_USERNAME, un);
        values.put(LoginDatabase.LoginTable.COL_PASSWORD, p);
        values.put(LoginDatabase.LoginTable.COL_FIRST_NAME, first);
        values.put(LoginDatabase.LoginTable.COL_LAST_NAME, last);
        values.put(LoginDatabase.LoginTable.COL_EMAIL, email);
        values.put(LoginDatabase.LoginTable.COL_ROLE, role);

        // Returns the login ID for the user
        return db.insert(LoginTable.TABLE, null, values);
    }

}
