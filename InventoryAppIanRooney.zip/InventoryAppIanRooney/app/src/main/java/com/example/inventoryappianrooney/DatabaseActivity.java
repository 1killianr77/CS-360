package com.example.inventoryappianrooney;

import static android.app.PendingIntent.getActivity;
import static android.content.Context.NOTIFICATION_SERVICE;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.preference.PreferenceManager;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;

public class DatabaseActivity extends AppCompatActivity {

    NavHostFragment navHostFragment;
    NavController navController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database);

        // Get nav host fragment
        navHostFragment = (NavHostFragment) getSupportFragmentManager()
                .findFragmentById(R.id.nav_host_fragment);

        // Get navController if database has entries
        if (navHostFragment != null) {
            navController = navHostFragment.getNavController();
        }
    }

    // Creates options menu in app bar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.database_menu, menu);   // inflate menu fragment view
        return true;
    }

    // User selects settings menu
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        // Start settings activity
        if (item.getItemId() == R.id.settings) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        return navController.navigateUp() || super.onSupportNavigateUp();
    }

    // FAB selected - add a new item
    public void AddItem(View view){

        // Starts AddNewItem activity
        Intent intent = new Intent(this, AddNewItem.class);
        startActivity(intent);
    }

    // Checkbox clicked - delete an item
    public void DeleteItem(View view){

        // Get delete confirmation from user
        AlertDialog.Builder builder;
        builder = new AlertDialog.Builder(view.getContext());
        builder.setTitle("Delete item?");

        // User selects positive button - delete item
        builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {

                // Deletes item in view
                DetailFragment.DeleteItem(view);

                // Restart Database activity
                Intent intent = new Intent(view.getContext(), DatabaseActivity.class);
                startActivity(intent);

                // Confirm deletion
                Toast.makeText(view.getContext(), "Item deleted." ,
                        Toast.LENGTH_LONG).show();
            }
        });

        // User selects negative button - cancel
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                Toast.makeText(view.getContext(), "Ok", Toast.LENGTH_SHORT).show();
            }
        });

        // Show dialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    // Update button selected on item page
    public void UpdateItem(View view) {
        // Update detail fragment and check whether item is out of stock
        boolean isOutOfStock = DetailFragment.UpdateItem(view);
        if (isOutOfStock){
            String name = DetailFragment.getItemName(view);    // Get item name

            // Create out of stock notification
            createNotificationChannel();
            createNotification(name + " is out of stock!");
        }
        // Restart Database activity
        Intent intent = new Intent(view.getContext(), DatabaseActivity.class);
        startActivity(intent);
    }

    private final static String CHANNEL_ID = "Low Inventory";   // Low Inventory channel

    // Creates the Low Inventory channel
    private void createNotificationChannel() {
        // Set channel properties
        CharSequence name = getString(R.string.channel_name);
        String description = getString(R.string.channel_description);
        int importance = NotificationManager.IMPORTANCE_DEFAULT;

        // Create notification channel
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
        channel.setDescription(description);

        // Register the channel with the system
        NotificationManager notificationManager = getSystemService(NotificationManager.class);
        notificationManager.createNotificationChannel(channel);
    }

    private final static int NOTIFICATION_ID = 0;   // Notification ID

    // Create a notification
    private void createNotification(String text) {

        // Set notification properties
        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle(getApplicationContext().getString(R.string.channel_name))
                .setContentText(text)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .build();

        // Post notification
        NotificationManagerCompat mNotificationManager = NotificationManagerCompat.from(this);
        SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(this);

        // Get notification preferences from settings
        boolean canNotify = sharedPrefs.getBoolean("@string/messagePreferences", true);

        // Send notification if permission granted
        if (!canNotify || (ActivityCompat.checkSelfPermission(this,
                android.Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED)) {
            return;
        }
        mNotificationManager.notify(NOTIFICATION_ID, notification); // Send notification
    }

}