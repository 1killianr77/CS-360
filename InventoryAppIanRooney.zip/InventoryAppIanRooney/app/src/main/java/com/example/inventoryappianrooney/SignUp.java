package com.example.inventoryappianrooney;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SignUp extends AppCompatActivity {

    private EditText mUNEditText;
    private EditText mPEditText;

    private EditText mFirstNameEditText;
    private EditText mLastNameEditText;
    private EditText mRoleEditText;
    private EditText mEmailEditText;
    Button mSignUp;

    LoginDatabase loginDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        // Sign up fields
        mUNEditText = findViewById(R.id.loginUsernameText);
        mPEditText = findViewById(R.id.loginTextPassword);
        mFirstNameEditText = findViewById(R.id.firstNameText);
        mLastNameEditText = findViewById(R.id.lastNameText);
        mRoleEditText = findViewById(R.id.userRoleText);
        mEmailEditText = findViewById(R.id.emailText);
        mSignUp = findViewById(R.id.buttonSignUp);

        // Access login database
        loginDatabase = new LoginDatabase(getApplicationContext());
    }

    // User presses Sign Up button to register
    public void Register(View view){

        // Get login information
        String mUsername = mUNEditText.getText().toString();
        String mPassword = mPEditText.getText().toString();
        String mFirst = mFirstNameEditText.getText().toString();
        String mLast = mLastNameEditText.getText().toString();
        String mRole = mRoleEditText.getText().toString();
        String mEmail = mEmailEditText.getText().toString();

        // Add user to the database
        long result = loginDatabase.addUser(mUsername, mPassword, mFirst, mLast, mRole, mEmail);

        // Check whether result was successful
        if (result != -1){
            Intent intent = new Intent(this, DatabaseActivity.class);
            startActivity(intent);
        }

        // Display an error message
        else{
            Toast.makeText(view.getContext(), "Please enter a unique username.",
                    Toast.LENGTH_LONG).show();
        }

    }

}