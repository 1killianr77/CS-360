package com.example.inventoryappianrooney;

import android.os.Bundle;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceFragmentCompat;
import androidx.preference.SwitchPreferenceCompat;

public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings_activity);

        // Gets fragment manager if user does not have saved settings
        if (savedInstanceState == null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.settings, new SettingsFragment())
                    .commit();
        }
        // Displays action bar for settings activity
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    public static class SettingsFragment extends PreferenceFragmentCompat {
        @Override
        public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
            // Retrieves settings layout file
            setPreferencesFromResource(R.xml.root_preferences, rootKey);

            // Locate the message preferences switch
            SwitchPreferenceCompat mNotificationPref = findPreference("@string/messagePreferences");

            // Check whether user has enabled notifications
            if (mNotificationPref != null) {
                // Set listener for notification permissions switch
                mNotificationPref.setOnPreferenceChangeListener((preference, newValue) -> {
                    return (Boolean) newValue; // true if notifications enabled
                });
            }
        }
    }
}