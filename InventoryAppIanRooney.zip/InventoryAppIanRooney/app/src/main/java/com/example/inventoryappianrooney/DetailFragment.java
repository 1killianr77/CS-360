package com.example.inventoryappianrooney;

import android.graphics.Bitmap;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link DetailFragment newInstance} factory method to
 * create an instance of this fragment.
 */
public class DetailFragment extends Fragment {
    private Item mItem;

    static final String ARG_ITEM_ID = "item_id";

    static ItemDatabase itemDatabase;

    static EditText mNameEditText;
    static EditText mIdEditText;
    static EditText mPriceEditText;
    static EditText mManufacturerEditText;

    static EditText mQtyEditText;

    static int itemId;

    Button mUpdateButton;

    public DetailFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        itemDatabase = new ItemDatabase(requireActivity().getApplicationContext());

        itemId = 1; // Default item Id

        Bundle args = getArguments();

        // Set itemId to item's database ID
        if (args != null) {
            itemId = args.getInt(ARG_ITEM_ID);
        }

        // Read item from database
        mItem = itemDatabase.readItem(itemId);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_detail, container, false);

        // Item has set values
        if (mItem != null){

            // Get item image and convert to Bitmap
            ImageView imageView = rootView.findViewById(R.id.itemImage);
            byte[] mImageBytes = mItem.getImage();
            Bitmap mImage = BitmapByteConversion.getImage(mImageBytes);
            imageView.setImageBitmap(mImage);

            // Item name
            mNameEditText = rootView.findViewById(R.id.itemNameText);
            mNameEditText.setText(String.valueOf(mItem.getName()));

            // Product ID
            mIdEditText = rootView.findViewById(R.id.itemID);
            mIdEditText.setText(String.valueOf(mItem.getProductId()));

            // Price
            mPriceEditText = rootView.findViewById(R.id.itemPrice);
            String mPrice = Float.toString(mItem.getPrice());
            mPriceEditText.setText(mPrice);

            // Manufacturer
            mManufacturerEditText = rootView.findViewById(R.id.itemManufacturer);
            mManufacturerEditText.setText(String.valueOf(mItem.getManufacturer()));

            // Quantity
            mQtyEditText = rootView.findViewById(R.id.item_quantity);
            mQtyEditText.setText(String.valueOf(mItem.getQty()));

            // Update item button
            mUpdateButton = rootView.findViewById(R.id.buttonUpdateItem);

        }
        return rootView;    // Return view for item
    }

    // Update item details in database
    public static boolean UpdateItem(View view) {

        // Get new name, product id, price, manufacturer, and quantity values
        String mName = mNameEditText.getText().toString();
        String mId = mIdEditText.getText().toString();
        float mPrice = Float.parseFloat(mPriceEditText.getText().toString());
        String mManufacturer = mManufacturerEditText.getText().toString();
        int mQuantity = Integer.parseInt(mQtyEditText.getText().toString());

        // Update item with matching id in the database
        itemDatabase.updateItem(itemId, null, mName, mId, mPrice, mManufacturer, mQuantity);

        return mQuantity == 0;  // Returns true if item is out of stock
    }

    // Delete item from the database
    public static void DeleteItem(View view) {
        itemDatabase.deleteItem(itemId);
    }

    // Return name of current item
    public static String getItemName(View view){
        return mNameEditText.getText().toString();
    }

}