package com.example.inventoryappianrooney;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ListFragment newInstance} factory method to
 * create an instance of this fragment.
 */
public class ListFragment extends Fragment {
    ItemDatabase itemDatabase;

    public ListFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getActivity() != null) {
            itemDatabase = new ItemDatabase(getActivity().getApplicationContext());
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_list, container, false);
        // Click listener for RecyclerView
        View.OnClickListener onClickListener = itemView -> {

            // Create fragment arguments for item ID
            int selectedItemId = (int) itemView.getTag();
            Bundle args = new Bundle();

            // Set item's ID to the database ID
            args.putInt(DetailFragment.ARG_ITEM_ID, selectedItemId);

            // Navigate to detail fragment when item is clicked
            Navigation.findNavController(itemView).navigate(R.id.show_item_detail, args);
        };

        // Fill RecyclerView with items
        RecyclerView recyclerView = rootView.findViewById(R.id.item_list);
        ArrayList<Item> itemList = itemDatabase.getInventory();
        recyclerView.setAdapter(new ItemAdapter(itemList, onClickListener));

        // Separate items with divider
        DividerItemDecoration divider = new DividerItemDecoration(recyclerView.getContext(),
                DividerItemDecoration.VERTICAL);
        recyclerView.addItemDecoration(divider);

        return rootView; // Return item list view
    }

    private class ItemAdapter extends RecyclerView.Adapter<ItemHolder>{
        private final ArrayList<Item> mItems;
        private final View.OnClickListener mOnClickListener;

        public ItemAdapter(ArrayList<Item> items, View.OnClickListener onClickListener){
            mItems = items;
            mOnClickListener = onClickListener;
        }

        // Create view holder for each item
        @NonNull
        @Override
        public ItemHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType){
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());
            return new ItemHolder(layoutInflater, parent);
        }

        // Bind items to the view holder and set the on click listener
        @Override
        public void onBindViewHolder(ItemHolder holder, int position){
            Item item = mItems.get(position);
            holder.bind(item);
            holder.itemView.setTag(item.getId());
            holder.itemView.setOnClickListener(mOnClickListener);
        }

        @Override
        public int getItemCount(){
            return mItems.size();
        }

    }

    private static class ItemHolder extends RecyclerView.ViewHolder{
        private final TextView mNameTextView;
        private final TextView mProductIdTextView;
        private final TextView mQuantityTextView;


        // Inflates the inventory list view to display the item list
        public ItemHolder(LayoutInflater inflater, ViewGroup parent){
            super(inflater.inflate(R.layout.list_item_inventory, parent, false));
            mNameTextView = itemView.findViewById(R.id.item_name);
            mProductIdTextView = itemView.findViewById(R.id.item_description);
            mQuantityTextView = itemView.findViewById(R.id.item_quantity);
        }

        // Binds each item's name, id, and quantity to the item holder
        public void bind(Item item){
            mNameTextView.setText(String.valueOf(item.getName()));
            mProductIdTextView.setText(String.valueOf(item.getProductId()));
            mQuantityTextView.setText(String.valueOf(item.getQty()));
        }

    }

}