package com.example.inventoryappianrooney;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class AddNewItem extends AppCompatActivity {

    EditText mNameEditText;
    EditText mIdEditText;
    EditText mPriceEditText;
    EditText mManufacturerEditText;
    EditText mQtyEditText;
    ImageView mItemImage;

    Button mAddItem;

    Bitmap mImageBitmap;
    byte[] mImage;

    ItemDatabase itemDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_item);

        // Text fields
        mNameEditText = findViewById(R.id.newItemNameText);
        mIdEditText = findViewById(R.id.itemID);
        mPriceEditText = findViewById(R.id.itemPrice);
        mManufacturerEditText = findViewById(R.id.itemManufacturer);
        mQtyEditText = findViewById(R.id.item_quantity);

        mAddItem = findViewById(R.id.buttonAddItem);    // Add new item button

        mItemImage = findViewById(R.id.itemImage);  // User selected image

        itemDatabase = new ItemDatabase(getApplicationContext());
    }

    // User taps default image to select an image
    public void selectImage(View view){
        mGetImageContent.launch("image/*");
    }

    // Get image selection from user
    private final ActivityResultLauncher<String> mGetImageContent = registerForActivityResult(
            new ActivityResultContracts.GetContent(),
            uri -> {
                try{
                    ImageDecoder.Source source = ImageDecoder.createSource(getContentResolver(), uri);
                    mImageBitmap = ImageDecoder.decodeBitmap(source);
                    mItemImage.setImageBitmap(mImageBitmap);
                } catch(IOException e) {
                    Toast.makeText(this, "Cannot display image", Toast.LENGTH_SHORT).show();
                }
            }
    );

    // Add item to the inventory database
    public void AddItem(View view){
        String mName = mNameEditText.getText().toString();
        String mId = mIdEditText.getText().toString();
        Float mPrice = Float.parseFloat(mPriceEditText.getText().toString());
        String mManufacturer = mManufacturerEditText.getText().toString();
        int mQuantity = Integer.parseInt(mQtyEditText.getText().toString());

        // Convert image to byte array
        if (mImageBitmap != null){
            mImage = BitmapByteConversion.getBytes(mImageBitmap);
        }
        else{
            mImage = null;
        }

        // Add item to database
        itemDatabase.createItem(mImage, mName, mId, mPrice, mManufacturer, mQuantity);

        // Return to DatabaseActivity
        Intent intent = new Intent(this, DatabaseActivity.class);
        startActivity(intent);
    }


}