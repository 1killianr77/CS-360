package com.example.inventoryappianrooney;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.CursorWindow;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.lang.reflect.Field;
public class MainActivity extends AppCompatActivity {

    private EditText mUNEditText;
    private EditText mPEditText;

    Button mLogin;
    Button mSignUp;

    LoginDatabase loginDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Login fields
        mUNEditText = findViewById(R.id.loginUsernameText);
        mPEditText = findViewById(R.id.loginTextPassword);

        mLogin = findViewById(R.id.buttonLogin); // Login button
        mSignUp = findViewById(R.id.buttonSignUp); // Sign Up button

        // Access the login database
        loginDatabase = new LoginDatabase(getApplicationContext());

        // request notification permissions for API 33 and above
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 1);
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_MEDIA_IMAGES}, 1);
        }

    }

    // User presses Login button
    public void Login(View view){
        // Get username and password
        String mUsername = mUNEditText.getText().toString();
        String mPassword = mPEditText.getText().toString();

        // Validate login
        if (loginDatabase.validateLogin(mUsername, mPassword)) {

            // Starts database activity if login information is correct
            Intent intent = new Intent(this, DatabaseActivity.class);
            startActivity(intent);
        }
        // Display error message
        else{
            Toast.makeText(view.getContext(), "Invalid username or password",
                    Toast.LENGTH_LONG).show();
        }
    }

    // User presses Sign Up button
    public void SignUp(View view){
        // Start sign up activity
        Intent intent = new Intent(this, SignUp.class);
        startActivity(intent);
    }

}