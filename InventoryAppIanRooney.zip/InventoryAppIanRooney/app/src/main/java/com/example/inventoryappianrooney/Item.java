package com.example.inventoryappianrooney;

// An inventory item
public class Item {

    private int mId; // Database ID
    private byte[] mImage; // Byte array to store image
    private String mName; // Item name
    private String mProductId;  // Product ID
    private String mManufacturer; // Manufacturer
    private float mPrice; // Price
    private int mQty; // Quantity

    public Item(){} // Empty item

    public Item(byte[] image, String name, String productId, float price, String manufacturer, int qty){
        mImage = image;
        mName = name;
        mProductId = productId;
        mPrice = price;
        mManufacturer = manufacturer;
        mQty = qty;
    }

    // Accessors
    public int getId(){
        return mId;
    }
    public byte[] getImage(){
        return mImage;
    }
    public String getName(){
        return mName;
    }
    public String getProductId(){
        return mProductId;
    }
    public float getPrice(){
        return mPrice;
    }
    public String getManufacturer(){
        return mManufacturer;
    }
    public int getQty(){
        return mQty;
    }

    // Mutators
    public void setId(int id){
        this.mId = id;
    }
    public void setImage(byte[] image){
        this.mImage = image;
    }
    public void setName(String name){
        this.mName = name;
    }
    public void setProductId(String productId){
        this.mProductId = productId;
    }
    public void setPrice(float price){
        this.mPrice = price;
    }

    public void setManufacturer(String manufacturer){
        this.mManufacturer = manufacturer;
    }
    public void setQty(int qty){
        this.mQty = qty;
    }
}
