package com.example.inventoryappianrooney;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.ByteArrayOutputStream;

public class BitmapByteConversion {

    // Convert bitmap to byte array
    public static byte[] getBytes(Bitmap bitmap){
        ByteArrayOutputStream bs = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 0, bs);
        byte[] image = bs.toByteArray();

        image = reduceSize(image);  // First reduce size

        return image;
    }

    // Convert byte array to bitmap
    public static Bitmap getImage(byte[] image) {
        // No image for this item
        if (image == null){
            return null;
        }
        return BitmapFactory.decodeByteArray(image, 0, image.length);
    }


    // Reduce image size for storage in database
    private static byte[] reduceSize(byte[] image){
        while (image.length > 500000){
            Bitmap bitmap = BitmapFactory.decodeByteArray(image, 0, image.length);

            // Scale length and width by 0.8
            Bitmap resized = Bitmap.createScaledBitmap(bitmap, (int)(bitmap.getWidth()*0.8),
                    (int)(bitmap.getHeight()*0.8), true );

            ByteArrayOutputStream stream = new ByteArrayOutputStream();

            // Compress size
            resized.compress(Bitmap.CompressFormat.PNG, 100, stream);
            image = stream.toByteArray();
        }
        return image;
    }
}
