package com.example.inventoryappianrooney;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class ItemDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "items.db";
    private static final int VERSION = 3;
    public ItemDatabase(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }

    // Defines table and column names
    private static final class ItemTable{
        private static final String TABLE = "items";
        private static final String COL_ID = "_id";

        private static final String COL_IMAGE = "image";
        private static final String COL_NAME = "name";
        private static final String COL_PRODUCT_ID = "productId";
        private static final String COL_PRICE = "price";
        private static final String COL_MANUFACTURER = "manufacturer";
        private static final String COL_QTY = "qty";
    }

    // Creates table with auto incremented integer key values
    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("create table " + ItemDatabase.ItemTable.TABLE + " (" +
                ItemTable.COL_ID + " integer primary key autoincrement, " +
                ItemTable.COL_IMAGE + " blob, " +
                ItemTable.COL_NAME + " text, " +
                ItemTable.COL_PRODUCT_ID + " text, " +
                ItemTable.COL_PRICE + " float, " +
                ItemTable.COL_MANUFACTURER + " text, " +
                ItemTable.COL_QTY + " integer)");
    }

    // Update database version
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("drop table if exists " + ItemDatabase.ItemTable.TABLE);
        onCreate(db);
    }

    // Revert to previous database version
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion){
        onUpgrade(db, oldVersion, newVersion);
    }

    // Add an item to the database
    public void createItem(byte[] image, String name, String productId, float price, String manufacturer, int qty){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        // Assign item image, name, product ID, price, manufacturer, and quantity
        values.put(ItemTable.COL_IMAGE, image);
        values.put(ItemTable.COL_NAME, name);
        values.put(ItemTable.COL_PRODUCT_ID, productId);
        values.put(ItemTable.COL_PRICE, price);
        values.put(ItemTable.COL_MANUFACTURER, manufacturer);
        values.put(ItemTable.COL_QTY, qty);

        // Insert new database row
        db.insert(ItemTable.TABLE, null, values);
    }


    // Find item with a matching ID
    public Item readItem(int id){
        SQLiteDatabase db = getReadableDatabase(); // Read only

        Item mItem = new Item();    // Returns empty item if not found

        // Locate matching item
        String sql = "select * from " + ItemTable.TABLE + " where _id = ? ";
        Cursor cursor = db.rawQuery(sql, new String[] { Integer.toString(id) });

        if (cursor.moveToFirst()){
            do{
                // Locate item variables
                byte[] image = cursor.getBlob(1);
                String name = cursor.getString(2);
                String productId = cursor.getString(3);
                float price = cursor.getFloat(4);
                String manufacturer = cursor.getString(5);
                int qty = cursor.getInt(6);

                // Assign item variables to mItem
                mItem = new Item(image, name, productId, price, manufacturer, qty);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return mItem; // Returns the matching item, otherwise returns an empty item
    }

    // Update item with a matching ID
    public boolean updateItem(int id, byte[] image, String name, String productId, float price,
                              String manufacturer, int qty){
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();

        // Assign new name, product ID, price, manufacturer, and quantity to the item
        values.put(ItemTable.COL_NAME, name);
        values.put(ItemTable.COL_PRODUCT_ID, productId);
        values.put(ItemTable.COL_PRICE, price);
        values.put(ItemTable.COL_MANUFACTURER, manufacturer);
        values.put(ItemTable.COL_QTY, qty);

        // Locate item with matching ID and update its values
        int rowsUpdated = db.update(ItemTable.TABLE, values, "_id = ?",
                new String[] {Integer.toString(id)});

        return rowsUpdated > 0; // Returns true if updated successfully
    }

    // Delete item with matching ID
    public void deleteItem(int id){
        SQLiteDatabase db = getWritableDatabase();

        // Find and delete the item with this ID
        db.delete(ItemTable.TABLE, ItemTable.COL_ID + " = ?",
                new String[]{Integer.toString(id)});

    }

    // Returns an arraylist of all items in the inventory
    public ArrayList<Item> getInventory(){

        ArrayList<Item> itemList = new ArrayList<Item>();
        SQLiteDatabase db = getReadableDatabase();

        String sql = "select * from " + ItemTable.TABLE;    // select all entries
        Cursor cursor = db.rawQuery(sql, null);

        if (cursor.moveToFirst()){
            do{
                Item mItem = new Item(); // Create new item for row in the database

                // Assign ID, image, name, product ID, price, manufacturer, and quantity
                mItem.setId(cursor.getInt(0));
                mItem.setImage(cursor.getBlob(1));
                mItem.setName(cursor.getString(2));
                mItem.setProductId(cursor.getString(3));
                mItem.setPrice(cursor.getFloat(4));
                mItem.setManufacturer(cursor.getString(5));
                mItem.setQty(cursor.getInt(6));

                // Add item to the list
                itemList.add(mItem);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return itemList;    // Return full inventory list
    }

}
